<?php

namespace Gladney;

defined( 'ABSPATH' ) || die;

class Install {

	public static function install() {

	}

	public static function uninstall() {
		
	}
}